// const template = <p id="par">BD Election</p>
// const myApp = document.querySelector("#test2");
// ReactDOM.render(template, myApp);
var v_namearr = [];
 var i_namearr = [];
 var r_namearr = [];
 var r_locarr = [];
 var i_pricearr = [];

 function getData(){
    var v_name = document.querySelector("#v-name").value;
    v_namearr.push(v_name);
    var i_name = document.querySelector("#i-name").value;
    i_namearr.push(i_name);
    var r_name = document.querySelector("#r-name").value;
    r_namearr.push(r_name);
    var r_loc = document.querySelector("#r-loc").value;
    r_locarr.push(r_loc);
    var i_price = document.querySelector("#i-price").value;
    i_pricearr.push(i_price);

    function attachItems(items) {
    var ul = document.querySelector("#test2");
    for(var i = 0; i < items.length; i++) {
        var li = makeListItem(items[i]);
        ul.appendChild(li);
    }
}

attachItems(v_namearr);
    // console.log(v_namearr, i_namearr, r_namearr, r_locarr, i_pricearr);
 }

